package org.univr.staticimp;

public class StaticSemanticsException extends RuntimeException { }
