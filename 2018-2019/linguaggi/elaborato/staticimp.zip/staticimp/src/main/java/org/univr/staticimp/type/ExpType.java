package org.univr.staticimp.type;

public abstract class ExpType extends Type { }
