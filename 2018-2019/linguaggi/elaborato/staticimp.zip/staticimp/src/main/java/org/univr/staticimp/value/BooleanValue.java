package org.univr.staticimp.value;

public class BooleanValue extends ExpValue<Boolean> {

    public BooleanValue(Boolean value) {
        super(value);
    }
}
