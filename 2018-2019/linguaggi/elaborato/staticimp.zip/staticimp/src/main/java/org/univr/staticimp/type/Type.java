package org.univr.staticimp.type;

public abstract class Type {

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
