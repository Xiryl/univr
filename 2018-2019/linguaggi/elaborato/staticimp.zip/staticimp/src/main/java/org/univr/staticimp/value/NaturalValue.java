package org.univr.staticimp.value;

public class NaturalValue extends ExpValue<Integer> {

    public NaturalValue(Integer value) {
        super(value);
    }
}
